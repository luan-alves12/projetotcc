<?php
$str_button      = '';
$str_chart_theme = '';
$str_grid_header_bg = "";
$str_google_fonts = "";
$str_widget_max = 'scriptcase__NM__btn__NM__scriptcase9_Rhino__NM__nm_scriptcase9_Rhino_max.png';
$str_widget_rest = 'scriptcase__NM__widget_res.png';
$index_class_pos = 'glyphicon-triangle-top';
$index_class_neg = 'glyphicon-triangle-bottom';
$index_class_neu = 'glyphicon-minus';
?>