<?php
$str_button      = 'scriptcase9_Rhino';
$str_chart_theme = '';
$str_grid_header_bg = "";
$str_google_fonts = "";
$str_toolbar_separator = 'scriptcase__NM__btn__NM__scriptcase9_Rhino__NM__nm_scriptcase9_Rhino_pipe.png';
$str_cal_ico_back = 'scriptcase__NM__img_move_left.gif';
$str_cal_ico_for = 'scriptcase__NM__img_move_right.gif';
$str_cal_ico_close = 'scriptcase__NM__img_move_close.png';
$str_bubble_tail = 'scriptcase__NM__help_arrow.png';
$str_block_exp = 'scriptcase__NM__btn__NM__scriptcase9_Rhino__NM__nm_scriptcase9_Rhino_open.png';
$str_block_col = 'scriptcase__NM__btn__NM__scriptcase9_Rhino__NM__nm_scriptcase9_Rhino_opened.png';
$index_class_pos = '';
$index_class_neg = '';
$index_class_neu = '';
?>