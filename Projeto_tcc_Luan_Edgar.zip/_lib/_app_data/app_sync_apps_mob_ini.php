<?php
    $arr_data = [];
    $arr_data['sc'] = "v9";
    $arr_data['sc_version'] = "9.9.020";
    $arr_data['sc_build'] = "5";
    $arr_data['prod_version'] = "1.0.000";
    $arr_data['prod_build'] = "3";
    $arr_data['initial'] = "app_sync_apps_mob.php";
    $arr_data['group'] = "healthcare";
    $arr_data['apl'] = "app_sync_apps_mob";
    $arr_data['status'] = "SIM";
    $arr_data['type'] = "contr";
    $arr_data['friendly_url'] = "app_sync_apps";
    $arr_data['md5'] = "LigMd5";
