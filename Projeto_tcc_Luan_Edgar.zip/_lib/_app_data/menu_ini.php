<?php
    $arr_data = [];
    $arr_data['sc'] = "v9";
    $arr_data['sc_version'] = "9.9.020";
    $arr_data['sc_build'] = "5";
    $arr_data['prod_version'] = "1.0.000";
    $arr_data['prod_build'] = "3";
    $arr_data['initial'] = "index.php";
    $arr_data['group'] = "healthcare";
    $arr_data['apl'] = "menu";
    $arr_data['status'] = "NAO";
    $arr_data['type'] = "MenuT";
    $arr_data['friendly_url'] = "menu";
    $arr_data['md5'] = "LigMd5";
